package com.example.android.project.utilities;

/**
 * Created by fypjadmin on 5/11/2016.
 */
public class UserUitilities {

    public static String username;

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        UserUitilities.username = username;
    }
}

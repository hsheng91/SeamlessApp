package com.example.android.project.models;

/**
 * Created by fypjadmin on 4/22/2016.
 */
public class Quiz {
    private String name;


    public Quiz(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
